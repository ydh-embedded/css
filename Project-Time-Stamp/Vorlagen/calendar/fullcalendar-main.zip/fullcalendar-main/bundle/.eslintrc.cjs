module.exports = {
  root: true,
  extends: require.resolve('@fullcalendar-scripts/standard/config/eslint.pkg.browser.cjs'),
}
