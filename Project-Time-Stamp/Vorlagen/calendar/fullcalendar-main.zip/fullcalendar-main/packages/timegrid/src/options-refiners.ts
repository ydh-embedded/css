export const OPTION_REFINERS = {
  allDaySlot: Boolean,
}
