made with IcoMoon (https://icomoon.io/app/#/select)

- Upload the IcoMoon project file (a JSON file)
- Must have "PRO" in order to do CSS data url embed
- In app, Generate Font > Download
- In resulting ZIP, grab style.css
- Rename to _icons.scss
- Reintroduce the "added for fc" statements

http://stephenscaff.com/articles/2013/09/font-face-and-base64-data-uri/
