import { createContext } from '../preact.js'

export const RenderId = createContext<number>(0)
