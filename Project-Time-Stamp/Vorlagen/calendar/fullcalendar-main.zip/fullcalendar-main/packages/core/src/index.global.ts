import * as Internal from './internal.js'
import * as Preact from './preact.js'

export * from './index.js'
export { Internal, Preact }
